# Customer 360 Assignment — Dataset

Five source extracts for the **Customer 360 Platform on Microsoft Fabric** assignment.
Place these in the `raw_data/` folder of your submission and land them into the Bronze layer.

| File | Rows | Grain |
|------|------|-------|
| crm_customers.csv | 82 | One row per customer (incl. 2 duplicate-ID rows) |
| crm_interactions.csv | 123 | One row per customer interaction |
| transactions.csv | 500 | One row per transaction (incl. 2 duplicate-ID rows) |
| kyc_records.csv | 81 | One row per KYC record (incl. 1 duplicate-ID row) |
| relationship_managers.csv | 5 | One row per RM / region (RLS mapping) |

Referential integrity: every `customer_id` in transactions, KYC, and interactions
resolves to a customer in `crm_customers.csv`; every `rm_id` resolves to
`relationship_managers.csv`. Use these keys for the Customer 360 joins.

PII columns (target of the Column-Level Security task): `email`, `phone`,
`date_of_birth` (crm_customers) and `document_number` (kyc_records).

RLS driver: `crm_customers.region` mapped to `relationship_managers.rm_login`.

---

## Seeded Data-Quality Issues (Instructor Answer Key)

Do not share this section with participants — it is the expected output of the
profiling task in the assignment.

**crm_customers.csv**
- 2 duplicate `customer_id` rows (one exact, one near-duplicate with a different email).
- 3 missing `full_name` values.
- 4 invalid `date_of_birth`: underage (~13), over-100, a future date, and one in `DD-MM-YYYY` format.
- Inconsistent `gender` values: `M`, `F`, `female` alongside the standard set.
- Inconsistent `region` casing / trailing space: `north`, `SOUTH`, `West `.
- Inconsistent `customer_segment` casing: `retail`, `PREMIUM`.
- Missing `email` (1) and missing `phone` (1).
- One `crm_created_date` in `DD/MM/YYYY` format instead of ISO.

**transactions.csv**
- 2 duplicate `transaction_id` rows.
- 3 negative `transaction_amount` values; 2 blank `transaction_amount` values.
- Inconsistent `transaction_status`: `SUCCESS`, `success`, `Succeeded`, `FAIL`, `pending`.
- Inconsistent `transaction_type` casing: `debit`, `upi`.
- One future `transaction_date` (2027).

**kyc_records.csv**
- 1 duplicate `kyc_id` row.
- Invalid `kyc_status` values: `Verifed` (typo), `Approved`, `VERIFIED` (casing).
- Invalid `risk_rating` values: `HIGH` (casing), `Critical`.
- 1 missing `document_number`.
- A subset of records are already expired (`expiry_date` in the past).

**crm_interactions.csv**
- Inconsistent `sentiment` casing: `positive`, `NEGATIVE`, `neutral`.
- Inconsistent `resolved_flag` formats: `Yes`, `No`, `1`, `0` alongside `Y` / `N`.

**relationship_managers.csv**
- Clean reference data (no seeded issues).
