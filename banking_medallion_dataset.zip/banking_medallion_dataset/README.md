# Banking Medallion Architecture Dataset

This dataset is designed for the assignment: Build a Banking Analytics Pipeline using Medallion Architecture and Dataflow Gen2.

## Files Included

- raw_data/customers.csv
- raw_data/accounts.csv
- raw_data/transactions.csv
- raw_data/transactions_late_arriving.csv
- raw_data/loans.csv
- raw_data/branches.csv
- data_dictionary.csv

## Intended Data Quality Issues

The dataset intentionally includes:
- Duplicate customer, account, transaction, loan, and branch records
- Missing customer names
- Invalid customer ages
- Inconsistent casing and spacing in city, region, gender, status, and channel values
- Null and negative balances
- Null and negative transaction amounts
- Invalid foreign keys such as B999, A99999, and C9999
- Invalid loan status and transaction status values
- A late-arriving transaction file for incremental-load practice

## Suggested Use

1. Load raw CSV files into the Bronze layer.
2. Use Dataflow Gen2 or notebooks to profile and clean the data.
3. Create Silver tables with standardized, validated data.
4. Create Gold tables for banking analytics and reporting.
