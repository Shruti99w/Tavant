-- =====================================================================
-- Core Banking SQL Database  (source system to be MIRRORED into Fabric)
-- Target dialect: Azure SQL Database / SQL Server (T-SQL)
-- NOTE: Transactions are NOT stored here; they arrive via the Transaction API.
-- =====================================================================

CREATE TABLE Branches (
    branch_id       NVARCHAR(10)  NOT NULL PRIMARY KEY,
    branch_name     NVARCHAR(100) NULL,
    city            NVARCHAR(50)  NULL,
    region          NVARCHAR(20)  NULL,
    branch_manager  NVARCHAR(100) NULL,
    rm_login        NVARCHAR(120) NULL
);

CREATE TABLE Customers (
    customer_id      NVARCHAR(10)  NOT NULL PRIMARY KEY,
    full_name        NVARCHAR(120) NULL,
    email            NVARCHAR(120) NULL,
    phone            NVARCHAR(20)  NULL,
    date_of_birth    DATE          NULL,
    gender           NVARCHAR(10)  NULL,
    city             NVARCHAR(50)  NULL,
    region           NVARCHAR(20)  NULL,
    customer_segment NVARCHAR(20)  NULL,
    kyc_status       NVARCHAR(20)  NULL,
    onboarding_date  DATE          NULL
);

CREATE TABLE Accounts (
    account_id      NVARCHAR(12)   NOT NULL PRIMARY KEY,
    customer_id     NVARCHAR(10)   NULL REFERENCES Customers(customer_id),
    branch_id       NVARCHAR(10)   NULL REFERENCES Branches(branch_id),
    account_type    NVARCHAR(20)   NULL,
    current_balance DECIMAL(18,2)  NULL,
    account_status  NVARCHAR(20)   NULL,
    open_date       DATE           NULL
);

CREATE TABLE Loans (
    loan_id            NVARCHAR(10)  NOT NULL PRIMARY KEY,
    customer_id        NVARCHAR(10)  NULL REFERENCES Customers(customer_id),
    loan_type          NVARCHAR(30)  NULL,
    loan_amount        DECIMAL(18,2) NULL,
    outstanding_amount DECIMAL(18,2) NULL,
    interest_rate      DECIMAL(5,2)  NULL,
    loan_status        NVARCHAR(20)  NULL,
    disbursed_date     DATE          NULL
);

CREATE TABLE Cards (
    card_id      NVARCHAR(10)  NOT NULL PRIMARY KEY,
    customer_id  NVARCHAR(10)  NULL REFERENCES Customers(customer_id),
    card_number  NVARCHAR(20)  NULL,   -- PII
    card_type    NVARCHAR(10)  NULL,
    card_status  NVARCHAR(15)  NULL,
    issue_date   DATE          NULL,
    expiry_date  DATE          NULL,
    credit_limit DECIMAL(18,2) NULL
);
GO

-- ---------- Seed data ----------

-- Branches
INSERT INTO Branches (branch_id, branch_name, city, region, branch_manager, rm_login) VALUES (N'BR01', N'Connaught Place Branch', N'Delhi', N'North', N'Anjali Mehta', N'anjali.mehta@bankcorp.com');
INSERT INTO Branches (branch_id, branch_name, city, region, branch_manager, rm_login) VALUES (N'BR02', N'MG Road Branch', N'Bengaluru', N'South', N'Suresh Iyer', N'suresh.iyer@bankcorp.com');
INSERT INTO Branches (branch_id, branch_name, city, region, branch_manager, rm_login) VALUES (N'BR03', N'Park Street Branch', N'Kolkata', N'East', N'Priya Das', N'priya.das@bankcorp.com');
INSERT INTO Branches (branch_id, branch_name, city, region, branch_manager, rm_login) VALUES (N'BR04', N'Andheri Branch', N'Mumbai', N'West', N'Rohit Shah', N'rohit.shah@bankcorp.com');
INSERT INTO Branches (branch_id, branch_name, city, region, branch_manager, rm_login) VALUES (N'BR05', N'MP Nagar Branch', N'Bhopal', N'Central', N'Vikram Nair', N'vikram.nair@bankcorp.com');

-- Customers
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0001', N'Riya Joshi', N'riya.joshi3@mail.com', N'9813998698', N'1989-01-15', N'Other', N'Jaipur', N'North', N'Premium', N'Verified', N'2017-11-27');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0002', N'Arjun Nair', N'arjun.nair57@mail.com', N'9707536455', N'1978-10-07', N'Other', N'Delhi', N'North', N'SME', N'Verified', N'2023-01-13');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0003', N'Arjun Chauhan', N'arjun.chauhan78@mail.com', N'9294055761', N'1980-10-11', N'Other', N'Guwahati', N'East', N'Retail', N'Verified', N'2023-09-25');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0004', N'Neha Joshi', N'neha.joshi38@mail.com', N'9469788093', N'1956-07-29', N'Male', N'Mumbai', N'West', N'Corporate', N'Verified', N'2022-05-29');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0005', N'Yash Nair', N'yash.nair20@mail.com', N'9778486488', N'1987-12-19', N'Female', N'Kochi', N'South', N'Premium', N'Verified', N'2020-01-07');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0006', N'Vivaan Das', N'vivaan.das49@mail.com', N'9978753477', N'1990-11-14', N'Female', N'Jaipur', N'North', N'Retail', N'Pending', N'2020-07-21');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0007', N'Siddharth Nair', N'siddharth.nair82@mail.com', N'9784726714', N'1989-09-19', N'Female', N'Mumbai', N'West', N'Premium', N'Verified', N'2021-08-12');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0008', NULL, N'pooja.sharma81@mail.com', N'9107981933', N'1955-11-03', N'Other', N'Bengaluru', N'South', N'SME', N'Verified', N'2024-02-16');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0009', N'Ananya Sharma', N'ananya.sharma1@mail.com', N'9599728379', N'1956-10-09', N'Other', N'Patna', N'East', N'Retail', N'Verified', N'2018-10-18');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0010', N'Manish Khanna', N'manish.khanna57@mail.com', N'9486628360', N'1954-07-10', N'Female', N'Bengaluru', N'South', N'Retail', N'Pending', N'2024-04-01');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0011', N'Siddharth Sharma', N'siddharth.sharma76@mail.com', N'9087547517', N'1986-11-10', N'Other', N'Bhubaneswar', N'East', N'Premium', N'Verified', N'2019-04-28');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0012', N'Nikhil Bose', N'nikhil.bose16@mail.com', N'9793186032', N'1949-01-22', N'Other', N'Mumbai', N'West', N'Corporate', N'Pending', N'2024-03-09');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0013', N'Aman Sharma', N'aman.sharma13@mail.com', N'9283822264', N'1983-03-01', N'Other', N'Kochi', N'South', N'Retail', N'Verified', N'2019-02-06');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0014', N'Ishaan Gupta', N'ishaan.gupta30@mail.com', N'9776472587', N'1984-11-20', N'Male', N'Patna', N'East', N'Retail', N'Pending', N'2019-08-06');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0015', N'Aditya Chauhan', N'aditya.chauhan42@mail.com', N'9568205258', N'2010-04-02', N'Other', N'Lucknow', N'North', N'Retail', N'Verified', N'2020-02-23');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0016', N'Anjali Khanna', N'anjali.khanna57@mail.com', N'9394948214', N'1953-08-26', N'Female', N'Indore', N'Central', N'Retail', N'Verified', N'2020-12-30');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0017', N'Isha Nair', N'isha.nair9@mail.com', N'9854914524', N'1967-12-24', N'Male', N'Bengaluru', N'South', N'Corporate', N'Pending', N'2019-11-19');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0018', N'Aarav Verma', N'aarav.verma50@mail.com', N'9130411895', N'1973-04-05', N'Female', N'Mumbai', N'West', N'Corporate', N'Verified', N'2019-06-03');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0019', N'Pooja Banerjee', N'pooja.banerjee36@mail.com', N'9158464506', N'1947-02-15', N'Female', N'Nagpur', N'Central', N'SME', N'Verified', N'2018-05-17');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0020', N'Anjali Banerjee', N'anjali.banerjee57@mail.com', N'9590853801', N'1959-07-19', N'Other', N'Kolkata', N'East', N'Retail', N'Verified', N'2022-11-11');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0021', N'Nikhil Patel', N'nikhil.patel99@mail.com', N'9069256663', N'1982-10-08', N'Other', N'Bhubaneswar', N'East', N'Premium', N'Verified', N'2017-04-27');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0022', N'Varun Singh', N'varun.singh57@mail.com', N'9642300487', N'1982-06-29', N'Female', N'Nagpur', N'Central', N'Premium', N'Rejected', N'2023-08-29');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0023', N'Shreya Shah', N'shreya.shah94@mail.com', N'9808458500', N'2001-04-30', N'Male', N'Jaipur', N'North', N'Retail', N'Rejected', N'2024-08-13');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0024', N'Yash Das', N'yash.das39@mail.com', N'9653845355', N'1986-03-16', N'Other', N'Raipur', N'Central', N'Corporate', N'Pending', N'2024-07-21');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0025', N'Arjun Mehta', N'arjun.mehta33@mail.com', N'9262705860', N'2002-05-04', N'Male', N'Bhopal', N'Central', N'SME', N'Verified', N'2019-12-22');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0026', N'Kavya Nair', N'kavya.nair58@mail.com', N'9083949066', N'1993-05-10', N'Other', N'Chennai', N'South', N'Retail', N'Verified', N'2021-05-14');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0027', N'Rohan Gupta', N'rohan.gupta95@mail.com', N'9409324484', N'1977-01-18', N'Male', N'Guwahati', N'East', N'Premium', N'Rejected', N'2024-01-24');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0028', N'Yash Pillai', N'yash.pillai80@mail.com', N'9765828025', N'1993-05-14', N'Male', N'Lucknow', N'North', N'Retail', N'Pending', N'2022-10-11');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0029', N'Shreya Rao', N'shreya.rao53@mail.com', N'9154382993', N'1956-05-08', N'Male', N'Chandigarh', N'North', N'Corporate', N'Verified', N'2017-10-27');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0030', N'Meera Pillai', N'meera.pillai61@mail.com', N'9415771883', N'1977-03-07', N'Other', N'Surat', N'West', N'SME', N'Verified', N'2017-12-26');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0031', N'Anjali Patel', N'anjali.patel38@mail.com', N'9432568855', N'2003-12-13', N'Female', N'Surat', N'West', N'SME', N'Verified', N'2022-03-12');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0032', N'Yash Rao', N'yash.rao41@mail.com', N'9569632792', N'1983-09-11', N'M', N'Hyderabad', N'South', N'Retail', N'Verified', N'2021-12-26');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0033', N'Ananya Singh', N'ananya.singh22@mail.com', N'9435281449', N'1986-02-04', N'Other', N'Guwahati', N'East', N'Corporate', N'Verified', N'2020-09-10');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0034', N'Riya Nair', N'riya.nair14@mail.com', N'9788365506', N'1960-07-08', N'Male', N'Ahmedabad', N'West', N'SME', N'Verified', N'2023-06-30');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0035', N'Rahul Menon', N'rahul.menon79@mail.com', N'9750031450', N'1963-10-09', N'Female', N'Nagpur', N'Central', N'SME', N'Verified', N'2024-10-07');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0036', N'Rohan Sharma', N'rohan.sharma71@mail.com', N'9125373924', N'1952-07-24', N'Other', N'Kochi', N'South', N'Premium', N'Verified', N'2020-01-15');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0037', N'Vivaan Shah', N'vivaan.shah4@mail.com', N'9883755559', N'1988-01-14', N'Female', N'Surat', N'West', N'SME', N'Pending', N'2017-05-31');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0038', N'Ananya Sharma', N'ananya.sharma27@mail.com', N'9754735486', N'1972-04-12', N'Male', N'Mumbai', N'West', N'Corporate', N'Pending', N'2024-03-28');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0039', N'Varun Singh', N'varun.singh28@mail.com', N'9479188957', N'1973-07-11', N'Other', N'Nagpur', N'Central', N'SME', N'Verified', N'2023-04-22');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0040', N'Anjali Gupta', N'anjali.gupta90@mail.com', N'9886193073', N'1963-10-24', N'Female', N'Chennai', N'South', N'Premium', N'Pending', N'2020-01-14');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0041', N'Ananya Singh', N'ananya.singh38@mail.com', N'9556898329', N'1994-06-18', N'Other', N'Pune', N'West', N'Premium', N'Verified', N'2024-05-14');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0042', N'Vivaan Verma', N'vivaan.verma92@mail.com', N'9442248527', N'1960-02-06', N'Male', N'Bhopal', N'Central', N'Premium', N'Verified', N'2021-08-23');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0043', N'Aman Singh', N'aman.singh98@mail.com', N'9043858176', N'1958-11-28', N'F', N'Indore', N'Central', N'Retail', N'Verified', N'2017-08-27');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0044', N'Karan Khanna', N'karan.khanna52@mail.com', N'9450283166', N'1962-11-23', N'Male', N'Lucknow', N'North', N'Premium', N'Verified', N'2022-07-19');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0045', N'Karan Shah', N'karan.shah29@mail.com', N'9866753478', N'1999-06-04', N'Female', N'Bengaluru', N'South', N'Premium', N'Verified', N'2018-04-20');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0046', N'Karan Pillai', N'karan.pillai89@mail.com', N'9212363608', N'1957-12-31', N'Other', N'Chandigarh', N'North', N'SME', N'Verified', N'2021-06-20');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0047', N'Aman Joshi', N'aman.joshi86@mail.com', N'9745721283', N'1977-03-17', N'Female', N'Jaipur', N'North', N'Retail', N'Rejected', N'2024-07-07');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0048', N'Riya Gupta', N'riya.gupta42@mail.com', N'9177588814', N'1971-08-17', N'Male', N'Bhopal', N'Central', N'Retail', N'Verified', N'2022-01-28');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0049', N'Diya Kulkarni', N'diya.kulkarni22@mail.com', N'9979780252', N'1947-05-22', N'Male', N'Raipur', N'Central', N'Retail', N'Verified', N'2019-11-11');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0050', N'Vivaan Iyer', N'vivaan.iyer13@mail.com', N'9981524735', N'1987-01-18', N'Other', N'Lucknow', N'North', N'Corporate', N'Verified', N'2020-07-04');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0051', N'Vivaan Menon', N'vivaan.menon30@mail.com', N'9392731979', N'1979-03-28', N'Female', N'Mumbai', N'West', N'Corporate', N'Rejected', N'2021-04-25');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0052', N'Sneha Chauhan', N'sneha.chauhan50@mail.com', N'9243854690', N'1976-09-17', N'Other', N'Lucknow', N'North', N'Retail', N'Verified', N'2019-06-08');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0053', N'Aditya Singh', N'aditya.singh17@mail.com', N'9276116603', N'1962-08-23', N'Male', N'Nagpur', N'Central', N'Premium', N'Verified', N'2021-03-13');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0054', N'Meera Shah', N'meera.shah77@mail.com', N'9038178057', N'1991-04-01', N'Other', N'Delhi', N'North', N'Premium', N'Verified', N'2022-05-27');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0055', N'Arjun Iyer', N'arjun.iyer43@mail.com', N'9214304907', N'1968-04-08', N'Male', N'Lucknow', N'North', N'Premium', N'Verified', N'2017-08-07');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0056', N'Karan Reddy', N'karan.reddy83@mail.com', N'9867130066', N'1994-11-15', N'Male', N'Raipur', N'Central', N'Premium', N'Verified', N'2018-11-06');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0057', N'Kabir Joshi', N'kabir.joshi69@mail.com', N'9564271051', N'1956-09-09', N'Other', N'Indore', N'Central', N'Corporate', N'Pending', N'2018-09-03');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0058', N'Ishaan Menon', N'ishaan.menon51@mail.com', N'9812061769', N'1975-05-19', N'Other', N'Patna', N'East', N'Retail', N'Verified', N'2023-08-19');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0059', N'Isha Gupta', N'isha.gupta27@mail.com', N'9316349992', N'1972-07-13', N'Other', N'Delhi', N'North', N'Retail', N'Verified', N'2018-12-20');
INSERT INTO Customers (customer_id, full_name, email, phone, date_of_birth, gender, city, region, customer_segment, kyc_status, onboarding_date) VALUES (N'CUST0060', N'Tara Nair', N'tara.nair79@mail.com', N'9372987112', N'1945-05-11', N'Other', N'Ahmedabad', N'West', N'Premium', N'Verified', N'2019-10-30');

-- Accounts
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1001', N'CUST0001', N'BR01', N'NRI', 867468.13, N'Active', N'2022-01-27');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1002', N'CUST0002', N'BR01', N'Salary', 48253.78, N'Active', N'2019-03-12');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1003', N'CUST0003', N'BR03', N'NRI', 838168.96, N'Active', N'2021-03-17');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1004', N'CUST0004', N'BR04', N'Savings', 765377.01, N'Active', N'2023-09-10');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1005', N'CUST0005', N'BR02', N'Salary', 1045767.95, N'Active', N'2024-10-02');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1006', N'CUST0006', N'BR01', N'Salary', NULL, N'Active', N'2023-11-22');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1007', N'CUST0007', N'BR04', N'Salary', 939420.93, N'Active', N'2017-02-25');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1008', N'CUST0008', N'BR02', N'NRI', 485182.12, N'Dormant', N'2021-01-31');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1009', N'CUST0009', N'BR03', N'Current', 699678.1, N'Active', N'2017-04-30');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1010', N'CUST0009', N'BR03', N'Savings', 296301.95, N'Active', N'2023-12-06');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1011', N'CUST0010', N'BR02', N'Current', 545156.31, N'Active', N'2017-05-08');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1012', N'CUST0011', N'BR03', N'Savings', 147479.52, N'Active', N'2022-02-17');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1013', N'CUST0012', N'BR04', N'Savings', 521330.06, N'Active', N'2017-01-15');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1014', N'CUST0013', N'BR02', N'Savings', 952560.98, N'Active', N'2022-03-03');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1015', N'CUST0014', N'BR03', N'Savings', 805092.17, N'Active', N'2019-02-21');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1016', N'CUST0015', N'BR01', N'NRI', 427092.67, N'Active', N'2017-12-21');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1017', N'CUST0015', N'BR01', N'Salary', 297014.96, N'Active', N'2018-02-12');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1018', N'CUST0016', N'BR05', N'NRI', 942353.55, N'Active', N'2017-03-26');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1019', N'CUST0016', N'BR05', N'NRI', 529669.9, N'Closed', N'2021-12-15');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1020', N'CUST0017', N'BR02', N'NRI', 595254.54, N'active', N'2017-07-12');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1021', N'CUST0018', N'BR04', N'NRI', 800908.02, N'Active', N'2023-02-11');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1022', N'CUST0019', N'BR05', N'NRI', 137556.06, N'Closed', N'2017-02-14');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1023', N'CUST0020', N'BR03', N'Salary', 323771.41, N'Active', N'2018-02-24');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1024', N'CUST0020', N'BR03', N'Current', 457071.22, N'Active', N'2021-08-09');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1025', N'CUST0021', N'BR03', N'Savings', 722966.88, N'Active', N'2020-07-31');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1026', N'CUST0021', N'BR03', N'NRI', 1072517.55, N'Dormant', N'2020-06-26');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1027', N'CUST0022', N'BR05', N'Current', 660170.21, N'Active', N'2023-03-26');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1028', N'CUST0023', N'BR01', N'NRI', 363736.26, N'Active', N'2019-12-04');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1029', N'CUST0024', N'BR05', N'NRI', 204981.66, N'Active', N'2020-06-19');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1030', N'CUST0025', N'BR05', N'Salary', 139237.53, N'Active', N'2017-01-08');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1031', N'CUST0025', N'BR05', N'Current', 751685.98, N'Active', N'2020-07-27');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1032', N'CUST0026', N'BR02', N'Savings', 826768.03, N'Active', N'2021-10-04');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1033', N'CUST0027', N'BR03', N'NRI', 845022.93, N'Closed', N'2021-10-30');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1034', N'CUST0028', N'BR01', N'NRI', 731062.23, N'Active', N'2021-01-07');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1035', N'CUST0029', N'BR01', N'Salary', 483851.79, N'Active', N'2019-10-26');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1036', N'CUST0030', N'BR04', N'Savings', 451170.57, N'Active', N'2023-10-07');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1037', N'CUST0030', N'BR04', N'Savings', 1079796.53, N'Active', N'2023-02-10');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1038', N'CUST0031', N'BR04', N'Savings', 962405.27, N'Active', N'2021-04-22');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1039', N'CUST0031', N'BR04', N'Salary', 1143236.34, N'Closed', N'2019-11-21');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1040', N'CUST0032', N'BR02', N'Current', 73500.56, N'Active', N'2017-07-23');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1041', N'CUST0033', N'BR03', N'NRI', 130254.12, N'Active', N'2022-10-16');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1042', N'CUST0034', N'BR04', N'Savings', 362425.14, N'Active', N'2021-09-10');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1043', N'CUST0035', N'BR05', N'Savings', 1134929.35, N'Active', N'2017-10-22');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1044', N'CUST0036', N'BR02', N'NRI', 47436.86, N'Active', N'2023-04-21');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1045', N'CUST0036', N'BR02', N'Savings', 945898.06, N'Dormant', N'2021-08-03');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1046', N'CUST0037', N'BR04', N'NRI', 238926.62, N'Active', N'2020-06-30');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1047', N'CUST0037', N'BR04', N'Current', 335453.18, N'Dormant', N'2023-01-06');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1048', N'CUST0038', N'BR04', N'NRI', 895263.81, N'Active', N'2023-06-10');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1049', N'CUST0039', N'BR05', N'NRI', 552202.0, N'Active', N'2017-01-04');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1050', N'CUST0040', N'BR02', N'Savings', 995628.77, N'Active', N'2020-01-10');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1051', N'CUST0041', N'BR04', N'NRI', 655543.56, N'Active', N'2020-08-09');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1052', N'CUST0041', N'BR04', N'Current', 954061.05, N'Active', N'2017-05-08');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1053', N'CUST0042', N'BR05', N'Current', 583691.46, N'Active', N'2021-05-21');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1054', N'CUST0042', N'BR05', N'Savings', 1072039.32, N'Active', N'2023-06-22');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1055', N'CUST0043', N'BR05', N'Salary', 691245.38, N'Active', N'2019-11-16');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1056', N'CUST0044', N'BR01', N'Savings', 1030427.55, N'Active', N'2019-07-12');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1057', N'CUST0045', N'BR02', N'Salary', 983493.12, N'Dormant', N'2018-12-01');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1058', N'CUST0046', N'BR01', N'Salary', 854379.2, N'Active', N'2023-08-06');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1059', N'CUST0047', N'BR01', N'Salary', 240039.59, N'Active', N'2021-01-13');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1060', N'CUST0048', N'BR05', N'Current', 779578.56, N'Active', N'2022-12-29');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1061', N'CUST0049', N'BR05', N'Salary', 1059607.76, N'Active', N'2020-02-05');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1062', N'CUST0050', N'BR01', N'Savings', 1146566.05, N'Active', N'2022-02-04');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1063', N'CUST0051', N'BR04', N'Savings', 260973.07, N'Active', N'2024-08-08');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1064', N'CUST0052', N'BR01', N'Savings', 599247.4, N'Active', N'2018-06-21');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1065', N'CUST0052', N'BR01', N'Savings', 1157569.04, N'Active', N'2021-11-17');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1066', N'CUST0053', N'BR05', N'Current', 818224.69, N'Dormant', N'2017-02-16');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1067', N'CUST0054', N'BR01', N'Salary', 253773.45, N'Active', N'2020-07-28');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1068', N'CUST0055', N'BR01', N'NRI', 1223403.45, N'Active', N'2024-08-29');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1069', N'CUST0056', N'BR05', N'Current', 54851.35, N'Active', N'2023-06-17');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1070', N'CUST0057', N'BR05', N'NRI', 862916.3, N'Active', N'2024-04-21');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1071', N'CUST0058', N'BR03', N'Salary', 253512.67, N'Dormant', N'2023-03-23');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1072', N'CUST0059', N'BR01', N'Salary', 997312.39, N'Active', N'2017-11-28');
INSERT INTO Accounts (account_id, customer_id, branch_id, account_type, current_balance, account_status, open_date) VALUES (N'ACC1073', N'CUST0060', N'BR04', N'Savings', 542581.02, N'Dormant', N'2017-08-03');

-- Loans
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN001', N'CUST0042', N'Personal Loan', 1612478.75, 0.0, 14.83, N'Closed', N'2024-10-02');
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN002', N'CUST0039', N'Business Loan', 1391916.31, 406943.84, 14.89, N'Active', N'2024-03-28');
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN003', N'CUST0003', N'Auto Loan', 1974712.56, 167754.02, 15.37, N'Active', N'2024-10-26');
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN004', N'CUST0031', N'Business Loan', 2469046.95, 0.0, 9.86, N'Default', N'2021-07-23');
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN005', N'CUST0010', N'Auto Loan', 4404035.39, 0.0, 12.45, N'Closed', N'2020-03-07');
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN006', N'CUST0043', N'Personal Loan', 3341594.31, 592457.85, 14.0, N'Active', N'2020-07-12');
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN007', N'CUST0057', N'Business Loan', 4191044.63, 2477479.85, 7.89, N'Active', N'2021-01-27');
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN008', N'CUST0026', N'Home Loan', 3852371.54, 0.0, 13.18, N'Closed', N'2021-02-04');
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN009', N'CUST0008', N'Home Loan', 3759492.67, 2778114.98, 14.35, N'Active', N'2023-11-22');
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN010', N'CUST0046', N'Home Loan', 2324359.88, 2556795.87, 13.79, N'Active', N'2021-02-21');
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN011', N'CUST0060', N'Personal Loan', 580332.3, 0.0, 16.04, N'Closed', N'2024-06-21');
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN012', N'CUST0023', N'Auto Loan', 4117220.26, 3712571.88, 7.62, N'Active', N'2021-03-06');
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN013', N'CUST0052', N'Business Loan', 4101188.31, 2204213.6, 10.01, N'Active', N'2023-10-22');
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN014', N'CUST0017', N'Personal Loan', 3390294.8, 3203464.91, 9.89, N'Active', N'2020-12-27');
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN015', N'CUST0048', N'Auto Loan', 1819512.58, 310038.68, 11.13, N'Defaulted', N'2024-04-07');
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN016', N'CUST0016', N'Home Loan', 3121440.83, 2190328.18, 15.46, N'Active', N'2018-06-25');
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN017', N'CUST0028', N'Business Loan', 2837012.56, 1710670.55, 7.96, N'Active', N'2018-03-14');
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN018', N'CUST0015', N'Personal Loan', 2690431.94, 0.0, 14.27, N'Closed', N'2024-08-31');
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN019', N'CUST0050', N'Auto Loan', 743550.36, 141853.21, 11.58, N'Active', N'2020-03-27');
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN020', N'CUST0014', N'Business Loan', 211051.19, 105313.21, 13.74, N'Active', N'2019-01-30');
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN021', N'CUST0018', N'Home Loan', 4038999.66, 3708039.0, 15.58, N'Active', N'2021-06-05');
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN022', N'CUST0041', N'Personal Loan', 1833149.8, 619056.37, 7.76, N'Active', N'2023-09-27');
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN023', N'CUST0030', N'Home Loan', 1119252.31, 0.0, 13.17, N'Closed', N'2018-01-15');
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN024', N'CUST0001', N'Business Loan', 4276560.53, 1256805.42, 16.18, N'Active', N'2022-10-31');
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN025', N'CUST0051', N'Personal Loan', 2241824.99, 718162.45, 15.73, N'Active', N'2018-12-01');
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN026', N'CUST0058', N'Home Loan', 4007881.94, 526572.32, 14.54, N'Active', N'2024-10-02');
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN027', N'CUST0034', N'Auto Loan', 3887110.57, 1658988.06, 14.58, N'Active', N'2024-10-08');
INSERT INTO Loans (loan_id, customer_id, loan_type, loan_amount, outstanding_amount, interest_rate, loan_status, disbursed_date) VALUES (N'LN028', N'CUST0054', N'Personal Loan', 3263993.71, 1812639.84, 12.85, N'Active', N'2023-09-14');

-- Cards
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD001', N'CUST0005', N'9734812417264366', N'Debit', N'Active', N'2022-07-20', N'2026-07-20', 50000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD002', N'CUST0048', N'9208242204262837', N'Debit', N'Active', N'2019-04-12', N'2023-04-12', 500000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD003', N'CUST0057', N'0601889870415178', N'Debit', N'Blocked', N'2023-02-03', N'2027-02-03', 50000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD004', N'CUST0013', N'2526956378276082', N'Debit', N'Active', N'2021-08-04', N'2025-08-04', 500000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD005', N'CUST0058', N'1213856070022386', N'Credit', N'Active', N'2023-07-08', N'2027-07-08', 100000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD006', N'CUST0032', N'4327465501351006', N'Debit', N'Blocked', N'2021-04-18', N'2025-04-18', 200000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD007', N'CUST0004', N'7112433516585098', N'Credit', N'Expired', N'2019-10-18', N'2023-10-18', 0);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD008', N'CUST0009', N'5431610302250215', N'Debit', N'Active', N'2020-03-07', N'2024-03-07', 0);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD009', N'CUST0055', N'4829418341908238', N'Credit', N'Active', N'2019-12-11', N'2023-12-11', 0);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD010', N'CUST0044', N'5212223863787760', N'Credit', N'Active', N'2021-07-19', N'2025-07-19', 100000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD011', N'CUST0007', N'2468542427641297', N'Credit', N'Active', N'2022-06-02', N'2026-06-02', 200000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD012', N'CUST0033', N'6047139360550496', N'Credit', N'Expired', N'2023-07-13', N'2027-07-13', 0);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD013', N'CUST0027', N'0564333879268771', N'Debit', N'Active', N'2023-08-19', N'2027-08-19', 500000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD014', N'CUST0008', N'4446940372056832', N'Credit', N'Active', N'2023-07-02', N'2027-07-02', 0);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD015', N'CUST0024', N'5689651648078820', N'Debit', N'Active', N'2024-05-09', N'2028-05-09', 50000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD016', N'CUST0036', N'0987695397110098', N'Credit', N'Active', N'2021-01-10', N'2025-01-10', 0);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD017', N'CUST0047', N'2822070169298442', N'Credit', N'Active', N'2019-05-01', N'2023-05-01', 0);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD018', N'CUST0053', N'2443177466432316', N'Credit', N'Blocked', N'2023-04-03', N'2027-04-03', 200000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD019', N'CUST0038', N'1415344796725218', N'Debit', N'Active', N'2020-10-10', N'2024-10-10', 50000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD020', N'CUST0039', N'1266869227138312', N'Credit', N'Active', N'2020-11-20', N'2024-11-20', 200000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD021', N'CUST0041', N'5029529207425657', N'Debit', N'Active', N'2020-01-07', N'2024-01-07', 200000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD022', N'CUST0050', N'3452606450114594', N'Credit', N'Active', N'2023-07-14', N'2027-07-14', 500000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD023', N'CUST0019', N'5845007485148101', N'Debit', N'Active', N'2023-10-28', N'2027-10-28', 0);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD024', N'CUST0052', N'6040837819596101', N'Debit', N'Active', N'2023-03-08', N'2027-03-08', 100000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD025', N'CUST0002', N'4461515753921025', N'Credit', N'Active', N'2022-03-16', N'2026-03-16', 0);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD026', N'CUST0026', N'1889049953142373', N'Debit', N'Active', N'2020-11-03', N'2024-11-03', 500000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD027', N'CUST0031', N'9516854247448059', N'Credit', N'Expired', N'2023-12-27', N'2027-12-27', 500000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD028', N'CUST0022', N'6558562528456186', N'Debit', N'Active', N'2019-07-05', N'2023-07-05', 100000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD029', N'CUST0021', N'1357506942669814', N'Debit', N'Active', N'2023-06-23', N'2027-06-23', 200000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD030', N'CUST0043', N'4307477763886918', N'Debit', N'Active', N'2019-12-01', N'2023-12-01', 100000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD031', N'CUST0018', N'8613406956314395', N'Credit', N'Active', N'2019-11-04', N'2023-11-04', 0);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD032', N'CUST0029', N'0756781724664122', N'Debit', N'Active', N'2024-09-24', N'2028-09-24', 100000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD033', N'CUST0011', N'2580257978176887', N'Credit', N'Active', N'2022-10-12', N'2026-10-12', 500000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD034', N'CUST0045', N'1797855756605548', N'Debit', N'Blocked', N'2023-07-08', N'2027-07-08', 200000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD035', N'CUST0014', N'0887853162448717', N'Credit', N'Active', N'2024-06-23', N'2028-06-23', 50000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD036', N'CUST0056', N'4032019172290357', N'Credit', N'Active', N'2023-07-26', N'2027-07-26', 500000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD037', N'CUST0051', N'7778545791016992', N'Debit', N'Active', N'2019-06-23', N'2023-06-23', 500000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD038', N'CUST0028', N'2717451435115937', N'Credit', N'Active', N'2021-02-21', N'2025-02-21', 200000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD039', N'CUST0054', N'4714732312452877', N'Debit', N'Active', N'2024-05-22', N'2028-05-22', 200000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD040', N'CUST0025', N'4043096428243143', N'Debit', N'Active', N'2022-01-13', N'2026-01-13', 0);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD041', N'CUST0016', N'3814957441586627', N'Debit', N'Expired', N'2024-09-27', N'2028-09-27', 100000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD042', N'CUST0035', N'0426511626958359', N'Debit', N'Active', N'2020-09-05', N'2024-09-05', 0);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD043', N'CUST0017', N'5286594605518300', N'Debit', N'Active', N'2019-07-18', N'2023-07-18', 100000);
INSERT INTO Cards (card_id, customer_id, card_number, card_type, card_status, issue_date, expiry_date, credit_limit) VALUES (N'CRD044', N'CUST0060', N'5557223488830226', N'Credit', N'Active', N'2023-04-26', N'2027-04-26', 0);
GO
