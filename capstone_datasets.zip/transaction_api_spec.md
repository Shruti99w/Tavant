# Transaction API — Specification

The core banking system exposes transaction events through a simple REST API.
For this capstone the feed is provided as a static file, `transactions_api_events.json`,
that mimics one page of an API response. Your Phase 2 ingestion should treat it as if
it were a live endpoint (call, paginate, land into Bronze).

## Endpoint (simulated)

```
GET /api/v1/transactions?since={ISO8601}&page={n}&page_size={n}
Authorization: Bearer <token>
```

## Response shape

```json
{
  "page": 1,
  "page_size": 602,
  "has_more": false,
  "events": [
    {
      "transaction_id": "TXN000002",
      "account_id": "ACC1071",
      "event_timestamp": "2025-01-13T05:48:00Z",
      "transaction_type": "Credit",
      "amount": 39617.14,
      "currency": "INR",
      "status": "Success",
      "channel": "ATM",
      "merchant_category": "Travel"
    }
  ]
}
```

| Field | Type | Notes |
|-------|------|-------|
| transaction_id | string | Event ID. May be re-delivered (duplicates possible). |
| account_id | string | FK to Accounts.account_id in the core banking DB. |
| event_timestamp | string (ISO 8601, UTC) | Use for incremental ingestion (`since` filter). |
| transaction_type | string | Debit, Credit, UPI, NEFT, IMPS, ATM. |
| amount | number | Transaction amount (can be malformed in the raw feed). |
| currency | string | Currency code, e.g. INR. |
| status | string | Success, Failed, Pending (casing not guaranteed). |
| channel | string | Mobile App, Internet Banking, ATM, Branch. |
| merchant_category | string | Retail, Travel, Utilities, Investment, Other. |

## Incremental ingestion

In production you would page through the feed and pass `since` equal to the maximum
`event_timestamp` you have already ingested. For this capstone, ingest the whole file
into `bronze_transactions`, add the `source_system`, `ingestion_timestamp` and
`pipeline_run_id` metadata columns, and design the pipeline so a `since` watermark
could drive incremental runs.

## Optional local mock

If you prefer a real HTTP call, serve the file locally, e.g.:

```
python -m http.server 8080
# then GET http://localhost:8080/transactions_api_events.json
```
