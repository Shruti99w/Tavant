# Capstone Dataset — Banking End-to-End on Microsoft Fabric

Source data for the capstone. Two source systems:

1. **Core Banking SQL Database** (to be MIRRORED) — five tables.
2. **Transaction API** (to be INGESTED) — JSON event feed.

## Files

| File | Use |
|------|-----|
| core_banking_schema.sql | DDL + seed inserts to stand up the source SQL database you will mirror (Azure SQL / SQL Server). |
| branches.csv | Core banking — Branches (also holds `rm_login`, the RLS driver). |
| customers.csv | Core banking — Customers (PII: email, phone, date_of_birth). |
| accounts.csv | Core banking — Accounts. |
| loans.csv | Core banking — Loans. |
| cards.csv | Core banking — Cards (PII: card_number). |
| transactions_api_events.json | Transaction API feed (one page; the Phase 2 ingestion source). |
| transactions.csv | Flattened convenience copy of the same events. |
| transaction_api_spec.md | API endpoint and payload spec. |

## Row counts

branches 5 · customers 60 · accounts 73 · loans 28 · cards 44 · API events 602 (incl. 2 duplicate IDs).

## Keys and integrity

- `Accounts.customer_id → Customers`, `Accounts.branch_id → Branches`.
- `Loans.customer_id → Customers`, `Cards.customer_id → Customers`.
- API `account_id → Accounts.account_id` (one intentional orphan, see below).
- Each customer's `region` matches the region of their branch, so `rm_login`
  (Branches) maps cleanly to a region for Row-Level Security.

## PII (Column-Level Security targets)

`Customers.email`, `Customers.phone`, `Customers.date_of_birth`, `Cards.card_number`.

---

## Seeded Data-Quality Issues (Instructor Answer Key)

Do not share with participants. The core banking (mirrored) source is mostly clean,
as a real OLTP system would be; the issues are concentrated in the API feed, which is
the focus of the Phase 3 profiling.

**Transaction API feed (transactions_api_events.json / transactions.csv)**
- 2 duplicate `transaction_id` events (re-delivered).
- 4 negative `amount` values, 1 zero `amount`, 1 missing `amount` (null/blank).
- Inconsistent `status`: `SUCCESS`, `success`, `Succeeded`, `FAIL`, `Failed`, `pending`.
- Inconsistent `transaction_type` casing: `debit`, `upi`.
- 1 future `event_timestamp` (2027).
- 1 orphan `account_id` (`ACC9999`) with no matching account — tests your join / reject logic.

**Core banking source (light, realistic)**
- customers: 1 missing `full_name`; 1 underage `date_of_birth`; 2 non-standard `gender` (`M`, `F`).
- accounts: 1 null `current_balance`; 1 lowercase `account_status` (`active`).
- loans: 1 invalid `loan_status` (`Default` instead of `Defaulted`); 1 `outstanding_amount` greater than `loan_amount`.
- cards: a few already past `expiry_date` / `Expired` status.
- branches: clean.
